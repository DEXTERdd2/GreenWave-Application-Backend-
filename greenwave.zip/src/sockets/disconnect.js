const disconnect = (socket) => {
  console.log("Disconnected");
};

module.exports = disconnect;
